# AEO-6 supported approval commands

Current checkpoint: AWAITING_DESIGN_APPROVAL. Requirements approval is already persisted for the unchanged scope.

Authenticated human design approval:

~~~powershell
Set-Location C:\Projects\agrosphere\agrosphere-orchestrator
.\.venv\Scripts\python.exe -m agrosphere_orchestrator.cli milestone approve-design AEO-6
~~~

Read-only verification after approval:

~~~powershell
Set-Location C:\Projects\agrosphere\agrosphere-orchestrator
.\.venv\Scripts\python.exe docs\milestones\AEO-6\evidence\verify_design_checkpoint.py --require-approval
~~~

See [the formal package](TECHNICAL_DESIGN_APPROVAL_PACKAGE.md) for exact hashes, review artifacts and generation/validation details. No autonomous execution command is implemented or authorized by this checkpoint.
